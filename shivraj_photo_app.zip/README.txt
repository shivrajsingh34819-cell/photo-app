How to put your app online for free (Shivraj's Product Photo Enhancer)
====================================================================

1. Go to https://github.com and create a free account (if you don't have one).
2. Click "New" to make a new repository (name it anything, like photo-enhancer).
3. Upload the index.html file from this folder to your new repository.
4. In the repository, go to Settings -> Pages -> Choose main branch -> Save.
5. Wait 1 minute, and your app will be live at https://YourName.github.io/YourRepo

--- OR ---

Use Netlify (super easy):
1. Go to https://netlify.com and sign up (free).
2. Drag and drop the index.html file into Netlify dashboard.
3. Done! You'll get a free link to share.

Contact Info on Page:
WhatsApp: +91 89577 93006
UPI: 8957793006@upi
